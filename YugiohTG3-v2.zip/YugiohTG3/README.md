# Yugioh TG3 v2

Catálogo Android offline inspirado em Yu-Gi-Oh! GX Tag Force 3.

## Versão 2
- Navegação Cartas / Boosters / DLC / Favoritos
- Busca offline
- Favoritos persistentes no aparelho
- 48 boosters catalogados
- Conteúdo DLC: 33 cartas + 2 receitas baixáveis
- Sem login e sem permissão de Internet

## Base de dados
O projeto inclui um banco local inicial. O script em `tools/import_full_database.py` pode ser usado para incorporar uma base completa de cartas quando disponível. Uma referência pública documenta 2.451 cartas jogáveis e 48 boosters para a família Tag Force. Consulte as fontes no projeto antes de redistribuir imagens/dados protegidos.
