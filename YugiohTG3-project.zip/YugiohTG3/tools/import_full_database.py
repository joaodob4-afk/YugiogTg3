#!/usr/bin/env python3
"""Helper: download the public Tag Force card-list repository and locate its data files.
Run this on a computer with internet access, then convert the repository's card data
into app/src/main/assets/cards.json using the format described in README.md.
"""
import io, json, os, zipfile, urllib.request
URL='https://github.com/KennethThomson/ygo-tag-force-card-list/archive/refs/heads/main.zip'
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
raw=urllib.request.urlopen(URL, timeout=60).read()
z=zipfile.ZipFile(io.BytesIO(raw))
z.extractall(os.path.join(root,'tools','source'))
base=os.path.join(root,'tools','source')
print('Downloaded source to:', base)
for d,_,fs in os.walk(base):
    for f in fs:
        if f.lower().endswith(('.json','.csv','.tsv')):
            print(os.path.join(d,f))
print('\nNext: inspect the listed data file and convert it to cards.json. The Android app expects local JSON and never accesses the network at runtime.')
