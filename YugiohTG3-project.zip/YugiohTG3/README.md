# Yugioh TG3 — Android offline catalog

Projeto Android em Java, sem login e sem permissão de Internet. O app possui:

- busca local de cartas;
- busca local de boosters;
- detalhes de carta;
- catálogo de 48 boosters do Yu-Gi-Oh! GX Tag Force 3;
- logo vetorial original com a marca “YUGIOH TG3”;
- banco JSON dentro de `app/src/main/assets`, portanto funciona sem conexão depois de compilado.

## Banco completo

A referência pública `KennethThomson/ygo-tag-force-card-list` documenta 2.451 cartas jogáveis e 48 boosters. Este pacote inclui um banco inicial de exemplo para manter o projeto leve e editável. Para incorporar a base completa antes de gerar o APK, use `tools/import_full_database.py` ou substitua `app/src/main/assets/cards.json` por um JSON no formato:

```json
[{"name":"Dark Magician","type":"Monster","rarity":"Ultra Rare","booster":"...","note":"..."}]
```

O app não faz chamadas de rede em execução.

## Como gerar o APK

1. Abra a pasta `YugiohTG3` no Android Studio.
2. Aguarde o Gradle sincronizar e instalar as dependências.
3. Selecione **Build > Build APK(s)**.
4. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Recomendado: Android Studio recente, JDK 17, Android SDK 35.

## Observação sobre imagens

A logo incluída é uma arte vetorial original feita para o aplicativo, evitando redistribuir artes oficiais do jogo. O projeto foi pensado como catálogo/fan reference e não inclui ROM, ISO ou arquivos do PSP.

## Fontes de referência

- KennethThomson/ygo-tag-force-card-list — base documentada de 2.451 cartas e 48 boosters.
- GameFAQs — Booster Pack FAQ do Tag Force 3, usado para conferir nomes, códigos e quantidades dos boosters.
